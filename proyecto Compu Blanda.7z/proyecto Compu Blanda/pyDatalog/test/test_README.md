# doctest
# coverage.py
# pythoscope
# entry points for pythoscope from doctest & coverage.py
